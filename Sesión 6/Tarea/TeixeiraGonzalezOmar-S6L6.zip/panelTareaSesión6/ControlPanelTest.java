import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Clase Test para la Clase ControlPanel
 *
 * @author  Omar Teixeira González
 * @version 23-10-20
 */
public class ControlPanelTest
{
    /**
     * Default constructor for test class ControlPanelTest
     */
    public ControlPanelTest()
    {
    }
    /*
     *Pruebas para el constructor con parámetros:
     * 1- Valor del Switch "OFF" y valor de la Lampara "APAGADO" (false y false)
     * 2- Valor del Switch "ON" y valor de la Lampara "ENCENDIDO" (true y true)
     */
    /**
     * 1- Valor del Switch "OFF" y valor de la Lampara "APAGADO" (false y false)
     */
    @Test
    public void testConstructorWithParamsOff()
    {
        Switch switch1 = new Switch(false);
        Lamp lamp1 = new Lamp(false);
        ControlPanel controlP1 = new ControlPanel(switch1, lamp1);
        assertEquals(false, switch1.getState());
        assertEquals(false, lamp1.getState());
    }
    
    /**
     * 2- Valor del Switch "ON" y valor de la Lampara "ENCENDIDO" (true y true)
     */
    @Test
    public void testConstructorWithParamsOn()
    {
        Switch switch1 = new Switch(true);
        Lamp lamp1 = new Lamp(true);
        ControlPanel controlP1 = new ControlPanel(switch1, lamp1);
        assertEquals(true, switch1.getState());
        assertEquals(true, lamp1.getState());
    }
    /*
     * Pruebas para el constructor con parámetros Potentiometer y Heater:
     * Positivo:
     * 1- Igual a los valores límites inferiores -> Cambiar los valores
     * 2- Igual a los valores límites superiores -> Cambiar los valores
     * 3- Entre los valores límites -> Cambiar los valores
     * 
     * Negativos:
     * 4- Inferiores a los valores límites -> No cambiar los valores
     * 5- Superiores a los valores límites -> No cambiar los valores
     */
    
    /**
     * 1- Igual a los valores límites inferiores -> Cambiar los valores
     */
    @Test
    public void testConstructorWithParamsInLowerLimits()
    {
        Potentiometer potentio1 = new Potentiometer(0);
        Heater heater1 = new Heater(10.0);
        ControlPanel controlP1 = new ControlPanel(potentio1, heater1);
        assertEquals(0, potentio1.getPosition());
        assertEquals(10.0, heater1.getTemperature(),0.1);
    }
    
    /**
     * 2- Igual a los valores límites superiores -> Cambiar los valores
     */
    @Test
    public void testConstructorWithParamsInUpperLimits()
    {
        Potentiometer potentio1 = new Potentiometer(10);
        Heater heater1 = new Heater(27.0);
        ControlPanel controlP1 = new ControlPanel(potentio1, heater1);
        assertEquals(10, potentio1.getPosition());
        assertEquals(27.0, heater1.getTemperature(),0.1);
    }
    
    /**
     * 3- Entre los valores límites -> Cambiar los valores
     */
    @Test
    public void testConstructorWithParamsInsideLimits()
    {
        Potentiometer potentio1 = new Potentiometer(5);
        Heater heater1 = new Heater(15.0);
        ControlPanel controlP1 = new ControlPanel(potentio1, heater1);
        assertEquals(5, potentio1.getPosition());
        assertEquals(15.0, heater1.getTemperature(),0.1);
    }
    
    /**
     * 4- Inferiores a los valores límites -> No cambiar los valores
     */
    @Test
    public void testConstructorWithParamsUnderLimits()
    {
        Potentiometer potentio1 = new Potentiometer(-5);
        Heater heater1 = new Heater(5.0);
        ControlPanel controlP1 = new ControlPanel(potentio1, heater1);
        assertEquals(10, potentio1.getPosition());
        assertEquals(27.0, heater1.getTemperature(),0.1);
    }
    
    /**
     * 5- Superiores a los valores límites -> No cambiar los valores
     */
    @Test
    public void testConstructorWithParamsOverLimits()
    {
        Potentiometer potentio1 = new Potentiometer(15);
        Heater heater1 = new Heater(30.0);
        ControlPanel controlP1 = new ControlPanel(potentio1, heater1);
        assertEquals(10, potentio1.getPosition());
        assertEquals(27.0, heater1.getTemperature(),0.1);
    }
    
    /*
     *Pruebas para el constructor con parámetros Switch, Lamp, Potentiometer y Heater:
     * 1- Valor de los objetos false, 5 y 15.0
     * 2- Valor de los objetos true, 10 y 27.0
     */
    /**
     * 1- Valor de los objetos false, 5 y 15.0
     */
    @Test
    public void testConstructorWithParams1()
    {
        Switch switch1 = new Switch(false);
        Lamp lamp1 = new Lamp(false);
        Potentiometer potentio1 = new Potentiometer (5);
        Heater heater1 = new Heater (15.0);
        ControlPanel controlP1 = new ControlPanel(switch1, lamp1, potentio1, heater1);
        assertEquals(false, switch1.getState());
        assertEquals(false, lamp1.getState());
        assertEquals(5, potentio1.getPosition());
        assertEquals(15.0, heater1.getTemperature(),0.1);
    }
    
    /**
     * 2- Valor de los objetos true, 10 y 27.0
     */
    @Test
    public void testConstructorWithParams2()
    {
        Switch switch1 = new Switch(true);
        Lamp lamp1 = new Lamp(true);
        Potentiometer potentio1 = new Potentiometer (10);
        Heater heater1 = new Heater (27.0);
        ControlPanel controlP1 = new ControlPanel(switch1, lamp1, potentio1, heater1);
        assertEquals(true, switch1.getState());
        assertEquals(true, lamp1.getState());
        assertEquals(10, potentio1.getPosition());
        assertEquals(27.0, heater1.getTemperature(),0.1);
    }
    
    /*
     * Pruebas del método press de la clase ControlPanel:
     * 1- El valor del switch y de la lampara es, respectivamente, ON y ENCENDIDA -> Cambiar a OFF y APAGADA
     * 2- El valor del switch y de la lampara es, respectivamente, OFF y APAGADA -> Cambiar a ON y ENCENDIDA
     */
    
    /**
     * 1- El valor del switch y de la lampara es, respectivamente, ON y ENCENDIDA -> Cambiar a OFF y APAGADA
     */
    @Test
    public void testPressOn()
    {
        Switch switch1 = new Switch(true);
        Lamp lamp1 = new Lamp(true);
        ControlPanel controlP1 = new ControlPanel(switch1, lamp1);
        controlP1.press(false);
        assertEquals("OFF", switch1.toString());
        assertEquals("APAGADA", lamp1.toString());
    }
    
    /**
     * 2- El valor del switch y de la lampara es, respectivamente, OFF y APAGADA -> Cambiar a ON y ENCENDIDA
     */
    @Test
    public void testPressOff()
    {
        Switch switch1 = new Switch(false);
        Lamp lamp1 = new Lamp(false);
        ControlPanel controlP1 = new ControlPanel(switch1, lamp1);
        controlP1.press(true);
        assertEquals("ON", switch1.toString());
        assertEquals("ENCENDIDA", lamp1.toString());
    }
    
    /*
     * Pruebas del método movePosition de la clase ControlPanel:
     * 1- Cuando el valor de la posición es 0 -> Temperatura del radiador es 10.0
     * 2- Cuando el valor de la posición es 10 -> Temperatura del radiador es 27.0 
     */
    
    /**
     * 1- Cuando el valor de la posición es 0 -> Temperatura del radiador es 10.0
     */
    @Test
    public void testMovePosition0()
    {
        Potentiometer potentio1 = new Potentiometer();
        Heater heater1 = new Heater();
        ControlPanel controlP1 = new ControlPanel(potentio1, heater1);
        controlP1.movePotentiometer(0);
        assertEquals(0, potentio1.getPosition());
        assertEquals(10.0, heater1.getTemperature(), 0.1);
    }
    
    /**
     * 2- Cuando el valor de la posición es 10 -> Temperatura del radiador es 27.0 
     */
    @Test
    public void testMovePosition10()
    {
        Potentiometer potentio1 = new Potentiometer();
        Heater heater1 = new Heater();
        ControlPanel controlP1 = new ControlPanel(potentio1, heater1);
        controlP1.movePotentiometer(10);
        assertEquals(10, potentio1.getPosition());
        assertEquals(27.0, heater1.getTemperature(), 0.1);
    }
}
